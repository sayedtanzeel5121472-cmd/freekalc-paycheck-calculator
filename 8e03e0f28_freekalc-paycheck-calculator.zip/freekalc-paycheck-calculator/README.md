# freekalc-paycheck-calculator

A tiny, dependency-free JavaScript engine for estimating US take-home pay: federal income tax (2025/2026 IRS brackets), Social Security, Medicare, state income tax, and pre-tax 401(k) contributions.

This is the open-source core of the free [FreeKalc Paycheck Calculator](https://freekalc.com/paycheck-calculator), a no-signup take-home pay calculator. A sibling tool covers the UK, Germany, Ireland and more on [freekalc.com](https://freekalc.com/).

## What it does

Given gross annual salary, filing status, state effective tax rate, and 401(k) contribution percentage, it returns:

- Net (take-home) annual, monthly, biweekly, and weekly pay
- A full deduction breakdown: federal tax, Social Security, Medicare, state tax, retirement

## Run the demo

Open `index.html` in any browser. No build step, no npm install, no dependencies. Just vanilla JavaScript you can read in one sitting.

## Use the engine

```html
<script src="src/paycheck.js"></script>
<script>
  // taxFed(taxableIncome, married) -> federal income tax
  // wire calcPaycheck() to your own inputs, or copy the ~60 lines
</script>
```

The whole engine is a single file, `src/paycheck.js`, small enough to paste into any project.

## Assumptions and limits

- Standard deduction: $15,000 single / $30,000 married (2025-2026)
- Social Security: 6.2% up to the $176,100 wage base
- Medicare: 1.45%, no additional surtax
- State tax: a single effective percentage you supply (see freekalc.com/paycheck-calculator for state-by-state effective rates)
- No itemized deductions, credits, or local/city taxes

Estimates only; not tax advice.

## License

MIT — use it in anything, including commercial projects. A link back to [freekalc.com](https://freekalc.com/) is appreciated but not required.

## More free calculators

- [UK salary calculator](https://freekalc.com/salary-calculator-uk)
- [VAT calculator (UK, Ireland, EU)](https://freekalc.com/vat-calculator)
- [$60,000 after tax by state](https://freekalc.com/blog/us-salary-after-tax-guide)
- [Mortgage calculator](https://freekalc.com/mortgage-calculator)
