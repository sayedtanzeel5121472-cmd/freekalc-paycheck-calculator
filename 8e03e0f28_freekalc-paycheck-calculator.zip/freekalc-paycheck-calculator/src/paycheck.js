function taxFed(taxable, married){
  var br = married ? [[23850,.10],[96950,.12],[206700,.22],[394600,.24],[501050,.32],[751600,.35],[1e12,.37]]
                   : [[11925,.10],[48475,.12],[103350,.22],[197300,.24],[250525,.32],[626350,.35],[1e12,.37]];
  var t=0, prev=0;
  for (var i=0;i<br.length;i++){
    var band = Math.min(taxable, br[i][0]) - prev;
    if (band>0) t += band*br[i][1];
    prev = br[i][0];
    if (taxable<=br[i][0]) break;
  }
  return t;
}
function calcPaycheck(){
  var g = +document.getElementById('salary').value||0;
  var married = document.getElementById('status').value==='married';
  var retPct = (+document.getElementById('ret').value||0)/100;
  var statePct = (+document.getElementById('state').value||0)/100;
  var std = married ? 30000 : 15000;
  var ret = g*retPct;
  var taxable = Math.max(0, g - ret - std);
  var fed = taxFed(taxable, married);
  var ss = Math.min(g,176100)*0.062;
  var med = g*0.0145;
  var st = g*statePct;
  var net = g - ret - fed - ss - med - st;
  var f = function(n){return '$'+n.toLocaleString('en-US',{maximumFractionDigits:0})};
  document.getElementById('out').innerHTML =
   '<div class="big">Take-home pay: '+f(net)+' / year</div>'+
   '<p>'+f(net/12)+' per month &middot; '+f(net/26)+' per biweekly paycheck &middot; '+f(net/52)+' per week</p>'+
   '<table><tr><th>Deduction</th><th>Amount / year</th></tr>'+
   '<tr><td>Federal income tax</td><td>'+f(fed)+'</td></tr>'+
   '<tr><td>Social Security (6.2%)</td><td>'+f(ss)+'</td></tr>'+
   '<tr><td>Medicare (1.45%)</td><td>'+f(med)+'</td></tr>'+
   '<tr><td>State income tax</td><td>'+f(st)+'</td></tr>'+
   '<tr><td>401(k) contributions</td><td>'+f(ret)+'</td></tr>'+
   '<tr><td><strong>Net annual pay</strong></td><td>'+f(net)+'</td></tr></table>';
}